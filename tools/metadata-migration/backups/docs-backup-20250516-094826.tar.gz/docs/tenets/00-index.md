# Tenets Index

This file contains an automatically generated list of all tenets with their one-line summaries.

_No tenets defined yet._
